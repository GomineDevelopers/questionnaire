<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
    <head>        
        <title>问卷后台管理</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="/Questionnaire/Public/Plugins/ui-frame/ui.css" />
        <link rel="stylesheet" type="text/css" href="/Questionnaire/Public/Plugins/dropzone/dropzone.css" />
        <link rel="stylesheet" type="text/css" href="/Questionnaire/Public/Css/Admin-default.css" />
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/jquery/jquery-2.1.1.min.js"></script>
    </head>


    <body>
        <div class="page-container">         
            <div class="page-sidebar">
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="<?php echo U('Index/index');?>">问卷系统后台</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li>                                                                      
                    <li>
                        <a href="<?php echo U('Questionnaire/index');?>"><span class="fa fa-files-o"></span> <span class="xn-text">问卷管理</span></a>
                    </li>                                        
                    <li class="xn-openable">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">回答管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Reply/all');?>"><span class="fa fa-list-ul"></span>成绩表</a></li>
                        	<li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li>
                        </ul>
                    </li>
                    <?php if(defined("IS_ROOT")): ?><li><a href="<?php echo U('Wechat/distribute');?>"><span class="fa fa-comments-o"></span>群发问卷</a></li>

                        <li><a href="<?php echo U('System/config');?>"><span class="fa fa-cogs"></span>系统配置</a></li><?php endif; ?>                                        
                </ul>
            </div>
            
            <div class="page-content">
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>

                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-caret-down"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span>注销</a></li>
                        </ul>                        
                    </li>                     

                    <li class="pull-right"><a>欢迎你， <?php echo ($authName); ?></a></li>                    
                </ul>
                
                <ul class="breadcrumb">
                    <li><span class="fa fa-home"></span> <a href="<?php echo U('Index/index');?>">问卷系统后台</a></li>
                    <?php if(is_array($breadcrumb)): $i = 0; $__LIST__ = $breadcrumb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if((count($breadcrumb)) != $i): ?><li><a href="<?php echo ($item["path"]); ?>"><?php echo ($item["name"]); ?></a></li>
                        <?php else: ?>
                            <li class="active"><?php echo ($item["name"]); ?></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>

                </ul>
                                
                <div class="page-content-wrap">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-body"> <form id="sysConfig-form" class="form-horizontal" action="<?php echo U('System/config');?>" method="post">
	<div class="form-group">
	    <blockquote class="blockquote-warning">
	        <h3><strong>公众号配置</strong></h3>
	    </blockquote>
	</div>

	<div class="form-group">
	    <label class="col-md-4 col-xs-12 control-label">AppID</label>
	    <div class="col-md-3 col-xs-12">                                            
	        <input name="weixin_AppID" type="text" class="form-control" value="<?php echo ($weixin_AppID); ?>" />
	    </div>
	</div>
	
	<div class="form-group">
	    <label class="col-md-4 col-xs-12 control-label">AppSecret</label>
	    <div class="col-md-3 col-xs-12">                                            
	        <input name="weixin_AppSecret" type="text" class="form-control" value="<?php echo ($weixin_AppSecret); ?>" />
	    </div>
	</div>
	
	<div class="form-group">
	    <label class="col-md-4 col-xs-12 control-label">Token</label>
	    <div class="col-md-3 col-xs-12">                                            
	        <input name="weixin_Token" type="text" class="form-control" value="<?php echo ($weixin_Token); ?>" />
	    </div>
	</div>	
		
	<div class="form-group">
	    <label class="col-md-4 col-xs-12 control-label">cryptType</label>
	    <div class="col-md-3 col-xs-12">                                            
	        <select name="weixin_cryptType" class="form-control select">
	        	<option value="0" <?php if( isset($weixin_cryptType) && ($weixin_cryptType==0) ) echo 'selected="selected"';?> >明文模式</option>
	        	<option value="1" <?php if( isset($weixin_cryptType) && ($weixin_cryptType==1) ) echo 'selected="selected"';?> >兼容模式</option>
	        	<option value="2" <?php if( isset($weixin_cryptType) && ($weixin_cryptType==2) ) echo 'selected="selected"';?> >安全模式</option>
	        </select>
	    </div>
	</div>	
		
	<div class="form-group">
	    <label class="col-md-4 col-xs-12 control-label">EncodingAESKey</label>
	    <div class="col-md-3 col-xs-12">                                            
	        <input name="weixin_EncodingAESKey" type="text" class="form-control" value="<?php echo ($weixin_EncodingAESKey); ?>" />
	    </div>
	</div>	
		
		
	<div class="form-group">
	    <blockquote class="blockquote-warning">
	        <h3><strong>问卷配置配置</strong></h3>
	    </blockquote>
	</div>

	<div class="form-group">
	    <label class="col-md-4 col-xs-12 control-label">问卷颜色主题</label>
	    <div class="col-md-3 col-xs-12">
            <select name="" class="form-control select">
                <option value="0">清新蓝</option>
                <option value="1">暗金黑</option>
                <option value="2">质朴白</option>
            </select>
	    </div>
	</div>	

	<div class="form-group">
	    <label class="col-md-4 col-xs-12 control-label">开启签名图</label>
	    <div class="col-md-3 col-xs-12">
            <label class="switch">
                <input type="checkbox" class="switch" value="1" checked/>
                <span></span>
            </label>
        </div>
	</div>	
	
	<div class="form-group">
	    <label class="col-md-4 col-xs-12 control-label"></label>
	    <div class="col-md-3 col-xs-12">
	    	<div class="row">
	            <div class="col-md-5"><input type="reset" class="btn btn-block btn-default" value=" 清 &nbsp; 空 " /></div>
	            <div class="col-md-5" style="float:right;"><button class="btn btn-block btn-info pull-right"> 提 &nbsp; 交 </button></div>
	    	</div>                                        
	    </div>
	</div>	
</form> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>

        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span><strong>注销?</strong></div>
                    <div class="mb-content">
                        <p>你确定要注销登录吗？</p>                    
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="<?php echo U('Auth/logout');?>" class="btn btn-success btn-lg">确定</a>
                            <button class="btn btn-default btn-lg mb-control-close">取消</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <audio id="audio-alert" src="/Questionnaire/Public/Audios/alert.mp3" preload="auto"></audio>

        <script type="text/javascript" src="/Questionnaire/Public/Plugins/jquery/jquery-ui.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/bootstrap/bootstrap.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/datatables/jquery-dataTables.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/ui-frame/plugins.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/ui-frame/actions.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/dropzone/dropzone.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/knob/knob.js"></script>
        <?php if(isset($extendJs)): ?><script type="text/javascript" src="/Questionnaire/Public/Js/Admin/<?php echo ($extendJs); ?>"></script><?php endif; ?>
    </body>
</html>