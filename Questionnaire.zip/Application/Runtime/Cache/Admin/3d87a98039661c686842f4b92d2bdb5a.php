<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
    <head>        
        <title>问卷后台管理</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="/Questionnaire/Public/Plugins/ui-frame/ui.css" />
        <link rel="stylesheet" type="text/css" href="/Questionnaire/Public/Plugins/dropzone/dropzone.css" />
        <link rel="stylesheet" type="text/css" href="/Questionnaire/Public/Css/Admin-default.css" />
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/jquery/jquery-2.1.1.min.js"></script>
    </head>


    <body>
        <div class="page-container">         
            <div class="page-sidebar">
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="<?php echo U('Index/index');?>">问卷系统后台</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li>                                                                      
                    <li>
                        <a href="<?php echo U('Questionnaire/index');?>"><span class="fa fa-files-o"></span> <span class="xn-text">问卷管理</span></a>
                    </li>                                        
                    <li class="xn-openable">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">回答管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Reply/all');?>"><span class="fa fa-list-ul"></span>成绩表</a></li>
                        	<li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li>
                        </ul>
                    </li>
                    <?php if(defined("IS_ROOT")): ?><li><a href="<?php echo U('Wechat/distribute');?>"><span class="fa fa-comments-o"></span>群发问卷</a></li>

                        <li><a href="<?php echo U('System/config');?>"><span class="fa fa-cogs"></span>系统配置</a></li><?php endif; ?>                                        
                </ul>
            </div>
            
            <div class="page-content">
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>

                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-caret-down"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span>注销</a></li>
                        </ul>                        
                    </li>                     

                    <li class="pull-right"><a>欢迎你， <?php echo ($authName); ?></a></li>                    
                </ul>
                
                <ul class="breadcrumb">
                    <li><span class="fa fa-home"></span> <a href="<?php echo U('Index/index');?>">问卷系统后台</a></li>
                    <?php if(is_array($breadcrumb)): $i = 0; $__LIST__ = $breadcrumb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if((count($breadcrumb)) != $i): ?><li><a href="<?php echo ($item["path"]); ?>"><?php echo ($item["name"]); ?></a></li>
                        <?php else: ?>
                            <li class="active"><?php echo ($item["name"]); ?></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>

                </ul>
                                
                <div class="page-content-wrap">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-body"> <div id="reply-statistic">
    <div class="questionnaire-info">
        <div  class="questionnaire-title">
            <?php switch($questionnaire["type"]): case "survey": ?><span class="label label-danger"><i class="fa fa-tag"></i>调研卷</span><?php break;?>
                <?php case "exam": ?><span class="label label-warning"><i class="fa fa-tag"></i>考试卷</span><?php break; endswitch;?>

            <h2><?php echo ($questionnaire["name"]); ?></h2>
        </div>

        <blockquote>
            <p><?php echo ($questionnaire["description"]); ?></p>
        </blockquote>

        <?php if(($questionnaire["type"]) == "exam"): ?><div class="widget widget-warning widget-item-icon">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                    <div class="widget-title"    style="font-family: '华文行楷'">平均分: <?php echo ($questionnaire["average"]); ?></div>

                    <div class="widget-title"    style="font-family: '华文行楷'">最高分: <?php echo ($questionnaire["max_score"]); ?></div>
                    <div class="widget-subtitle" style="font-family: '华文新魏'">由 <?php echo ($questionnaire["max_nicknames"]); ?> 获得</div>

                    <div class="widget-title"    style="font-family: '华文行楷'">最低分: <?php echo ($questionnaire["min_score"]); ?></div>
                    <div class="widget-subtitle" style="font-family: '华文新魏'">由 <?php echo ($questionnaire["min_nicknames"]); ?> 获得</div>
                </div>
            </div><?php endif; ?>
    </div>

    <div class="statistic">
        <?php if(is_array($questions)): $i = 0; $__LIST__ = $questions;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$question): $mod = ($i % 2 );++$i;?><div class="question">
                <?php if(($question["questionnaire_type"]) == "exam"): ?><div class="extend-info">
                        <div class="rate">
                            <p>准确率/%</p>
                            <input class="knob" data-width="100" data-height="100" data-fgColor="#FD421C" value="<?php echo ($question["rate"]); ?>"/>
                        </div>
                        <div class="extend-detail">
                            <div class="right-cnt">
                                <p>正确人数: <?php echo ($question["rightCnt"]); ?></p>
                            </div>
                            <div class="false-cnt">
                                <p>错误人数: <?php echo ($question["falseCnt"]); ?></p>
                            </div>
                            <div class="stardard">
                                <p>标准答案:</p>
                                <p class="standard-highlight">
                                    <?php if(is_array($question["standard"])): foreach($question["standard"] as $key=>$item): echo ($item); ?> <br /><?php endforeach; endif; ?>
                                </p>
                            </div>
                        </div>
                    </div><?php endif; ?>

                <div class="info">
                    <p class="name"><?php echo ($i); ?> <?php echo ($question["name"]); ?></p>

                    <ul class="options">
                        <?php if(is_array($question["options"])): $optionIndex = 0; $__LIST__ = $question["options"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$option): $mod = ($optionIndex % 2 );++$optionIndex;?><li>
                                <?php switch($option["type"]): case "radio": ?><div class="detail"><input type="radio"/> <strong class="option-index"><?php echo ($optionIndex); ?></strong> <?php echo ($option["text"]); ?></div>
                                            <?php if(isset($option["count"])): ?><div class="option-statistic">该项勾选人数: <?php echo ($option["count"]); ?></div><?php endif; break;?>
                                        <?php case "checkbox": ?><div class="detail"><input type="checkbox"/> <strong class="option-index"><?php echo ($optionIndex); ?></strong> <?php echo ($option["text"]); ?></div>
                                            <?php if(isset($option["count"])): ?><div class="option-statistic">该项勾选人数: <?php echo ($option["count"]); ?></div><?php endif; break;?>
                                        <?php case "radio_othertext": ?><div class="detail"><input type="radio"/><strong class="option-index"><?php echo ($optionIndex); ?></strong> <div>其他<br /> <textarea cols="30" rows="5"></textarea></div></div>
                                            <?php if(isset($option["count"])): ?><div class="option-statistic">
                                                    该项勾选人数: <?php echo ($option["count"]); ?>
                                                    <div class="reply-list">
                                                        回答摘要
                                                        <textarea cols="30" rows="5"><?php if(is_array($option["replyList"])): foreach($option["replyList"] as $key=>$reply): echo ($reply); ?>------------------------------<?php endforeach; endif; ?></textarea>
                                                    </div>
                                                </div><?php endif; break;?>
                                        <?php case "checkbox_othertext": ?><div class="detail"><input type="checkbox"/> <strong class="option-index"><?php echo ($optionIndex); ?></strong> <div>其他<br /> <textarea cols="30" rows="5"></textarea></div></div>
                                            <?php if(isset($option["count"])): ?><div class="option-statistic">
                                                    该项勾选人数: <?php echo ($option["count"]); ?>
                                                    <div class="reply-list">
                                                        回答摘要
                                                        <textarea cols="30" rows="5"><?php if(is_array($option["replyList"])): foreach($option["replyList"] as $key=>$reply): echo ($reply); ?>------------------------------<?php endforeach; endif; ?></textarea>
                                                    </div>
                                                </div><?php endif; break;?>
                                        <?php case "text": ?><div class="detail"><textarea cols="30" rows="5"></textarea></div>
                                            <?php if(isset($option["replyList"])): ?><div class="option-statistic">
                                                    <div class="reply-list">
                                                        回答摘要
                                                        <textarea cols="30" rows="5"><?php if(is_array($option["replyList"])): foreach($option["replyList"] as $key=>$reply): echo ($reply); ?>------------------------------<?php endforeach; endif; ?></textarea>
                                                    </div>
                                                </div><?php endif; break; endswitch;?>
                            </li><?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </div>
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
</div> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>

        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span><strong>注销?</strong></div>
                    <div class="mb-content">
                        <p>你确定要注销登录吗？</p>                    
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="<?php echo U('Auth/logout');?>" class="btn btn-success btn-lg">确定</a>
                            <button class="btn btn-default btn-lg mb-control-close">取消</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <audio id="audio-alert" src="/Questionnaire/Public/Audios/alert.mp3" preload="auto"></audio>

        <script type="text/javascript" src="/Questionnaire/Public/Plugins/jquery/jquery-ui.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/bootstrap/bootstrap.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/datatables/jquery-dataTables.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/ui-frame/plugins.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/ui-frame/actions.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/dropzone/dropzone.js"></script>
        <script type="text/javascript" src="/Questionnaire/Public/Plugins/knob/knob.js"></script>
        <?php if(isset($extendJs)): ?><script type="text/javascript" src="/Questionnaire/Public/Js/Admin/<?php echo ($extendJs); ?>"></script><?php endif; ?>
    </body>
</html>